
 
<?php
session_start();
if(empty($_SESSION['email']))
{
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <link rel="stylesheet" type="text/css" href="../css.css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style>
	body
	{
		background-image:url(background.png);
		background-repeat: no-repeat; 
		background-attachment: fixed;
		background-size: 100% 100%;
	}
</style>
<title>Project Management System</title>
</head>
<div>
<body>
<table width="100%"  cellspacing="00" cellpadding="00">
  <tr bgcolor="#D2691E">
    <th width="7%" scope="col">&nbsp;</th>
    <th width="12%" scope="col"><img src="images/logo1.png" alt="LOGO"/></th>
    <th width="62%" scope="col"><font size="8" color="White">Project Managenent System</font></th>
    <th width="13%" scope="col"><font size="5" color="White">&nbsp;</font></th>
    <th width="6%" scope="col">&nbsp;</th>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><br/><br/><div style="width:50%;background-color:#FFF8DC;margin-left:24%;margin-top:100px;border:1px solid black;">
    	<br><br>
                <form name="login" action="index.php" method="post">
                    
        <table width="100%"  cellspacing="02" cellpadding="05">
  <tr>
      <th colspan="2" scope="col"><font size="6">LOGIN</font></th>
    </tr>
  <tr>
      <td align="right"><font size="5">ID&nbsp;:&nbsp;</font></td>
    <td><input style="height: 20px; font-size: 15px;" type="text" name="id"/><br/>
    </td>
  </tr>
  <tr>
      <td align="right"><font size="5">Password&nbsp;:&nbsp;</font></td>
    <td><input style="height: 20px; font-size: 15px;" type="password" name="pass" /></td>
  </tr>
  <tr>
      <td align="right"><font size="5">Login_As&nbsp;:&nbsp;</font></td>
    <td>
        <select name="role" style="width: 13em; height: 2em; font-size: 15px;">
        <option value="Student">Student</option>
        <option value="Faculty">Faculty</option>
        <option value="Admin">Admin</option>          
        </select>
      </td>
  </tr>
            <tr>
                <td colspan="2" align="center"><input type="submit" style="width: 4em;  height: 2em; font-size: 20px;" name="register" value="Submit" /></td>
            </tr>
</table> 

        <br/>
        &nbsp;
        </form>
    	</div>
     </td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</div>
    
</html>

<?php
}
else
{
header("location:Admin.php");
}

?>
<?php
if (isset($_POST['id'])) {
$user = $_POST['id'];
}
if (isset($_POST['pass'])) {
$pass = $_POST['pass'];
}
if (isset($_POST['role'])) {
$role = $_POST['role'];
}

include 'connection.php';

if($role == "Admin")
{
    if(!empty($user)||!empty($pass)){
$sql = "SELECT * FROM admin WHERE ID='$user' AND password='$pass'";
$res = mysqli_query($conn,$sql);
$count = mysqli_num_rows($res);

		if($count == 0)
		{
		header("location:Admin.php");
		}
		else
		{
			$_SESSION['Email'] = $user;
			$_SESSION['Role'] = $role;
			header("location:Admin.php?image=image.php");
		}
}
 else {
       
      
           
     echo"<script>alert( 'Fill up al fields');</script>";

    }
}
else if($role == "Faculty")
{
        if(!empty($user)||!empty($pass)){
	$sql = "SELECT * FROM faculty WHERE f_id='$user' AND password='$pass'";
	$res = mysqli_query($conn,$sql);
	$count = mysqli_num_rows($res);

		if($count == 0)
		{
		echo "<script>alert('username password Incorrect');</script>";
		redirect("login.php");
		}
		else
		{
			$_SESSION['Email'] = $user;
			$_SESSION['Role'] = $role;
			header("location:Admin.php?image=image.php");
		}
        }
 else {echo"<script>alert( 'Fill up all fields');</script>";}
}
else
{
        if(!empty($user)||!empty($pass)){
	$sql = "SELECT * FROM student WHERE s_id='$user' AND password='$pass'";
	$res = mysqli_query($conn,$sql);
	$count = mysqli_num_rows($res);

		if($count == 0)
		{
		echo "<script>alert('username password Incorrect');</script>";
		}
		else
		{
			$_SESSION['Email'] = $user;
			$_SESSION['Role'] = $role;
			header("location:Admin.php?image=image.php");
		}
        }
 else {echo"<script>alert( 'Fill up all fields');</script>";}
}

?>
